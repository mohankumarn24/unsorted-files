package com.projectsync.surveylink.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.projectsync.surveylink.repository.BookRepository;

@Service
public class EmployeeService {
	
	@Autowired
	BookRepository employeeRepository;

}
