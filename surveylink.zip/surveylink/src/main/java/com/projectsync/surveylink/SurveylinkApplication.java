package com.projectsync.surveylink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SurveylinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SurveylinkApplication.class, args);
	}

}
