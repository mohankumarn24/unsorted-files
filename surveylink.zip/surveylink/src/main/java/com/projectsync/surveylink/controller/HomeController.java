package com.projectsync.surveylink.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.projectsync.surveylink.service.EmployeeService;

@RestController
public class HomeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping(path = {"/", "/welcome", "/hello"})
	public String welcome() {
		
		return "hello, world";
	}
}
