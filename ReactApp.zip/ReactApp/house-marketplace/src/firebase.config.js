// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getFirestore} from "firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBJhx7rAKSkTZiWcb5K1dYvRCBmxMhy-ng",
  authDomain: "house-marketplace-app-aa83b.firebaseapp.com",
  projectId: "house-marketplace-app-aa83b",
  storageBucket: "house-marketplace-app-aa83b.appspot.com",
  messagingSenderId: "320931697079",
  appId: "1:320931697079:web:659c71c84646206c7e9832"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const db = getFirestore()