const FeedbackData = [
    {
        id: 1,
        rating: 7,
        text: 'dsdjkf usdhf sd sdfof soldfs fsofs ol'
      },
      {
        id: 2,
        rating: 10,
        text: 'jhdf nikzx xzx sdzd klsdops fn lasda ldan'
      },
      {
        id: 3,
        rating: 6,
        text: 'xjchdo dsfosd fsdiofjof sdo  oidfjosd'
      }    
]

export default FeedbackData