import Task from "./Task"

const Tasks = ({ tasks, onDelete, onToggle }) => {
  return (
    <>
        {tasks.map((individualTask) => (
            <Task key={individualTask.id} task={individualTask} onDelete={onDelete} onToggle={onToggle}/>
        ))}
    </>
  )
}

export default Tasks