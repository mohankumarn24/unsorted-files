import { createContext, useReducer } from 'react'
import githubReducer from './GithubReducer'

const GithubContext = createContext()

export const GithubProvider = ({ children }) => {

  const [{users, user, repos, loading}, dispatch] = useReducer(githubReducer, {
    users: [],
    user: {},
    repos: [],
    loading: false,
  })

  return (
    <GithubContext.Provider
      value={{
        users,
        user,
        repos,
        loading,
        dispatch,
      }}
    >
      {children}
    </GithubContext.Provider>
  )
}

export default GithubContext
