package com.projectsync.iamuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IamUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
