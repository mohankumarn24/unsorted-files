package com.projectsync.iamuser.mapper;

import com.projectsync.iamuser.dto.UserRequest;
import com.projectsync.iamuser.dto.UserResponse;
import com.projectsync.iamuser.entity.User;

public class UserMapper {

    private UserMapper() {

    }

    public static User mapUserToEntity(UserRequest userRequest) {

        User user = new User();
        user.setFirstName(userRequest.getFirstName());
        user.setLastName(userRequest.getLastName());
        user.setAddress(userRequest.getAddress());
        user.setEmail(userRequest.getEmail());

        return user;
    }

    public static UserResponse mapUserToDto(User user) {

        UserResponse userResponse = new UserResponse();
        userResponse.setId(user.getId());
        userResponse.setFirstName(user.getFirstName());
        userResponse.setLastName(user.getLastName());
        userResponse.setAddress(user.getAddress());
        userResponse.setEmail(user.getEmail());

        return userResponse;
    }
}
